﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

	// Let's Color GTR3 Pro
	// 2023 © leXxiR  4pda

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
		let normal_weather_image_progress_img_level = ''
		let normal_system_disconnect_img = ''
		let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
		let normal_fat_burning_current_text_img = ''
		let normal_stand_current_text_img = ''
		let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
		let idle_system_disconnect_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let normal_temperature_jumpable_img_click = ''
		let bg_fill = ''
		let bgColor = [0x37ffc8, 0xe27d01, 0x0d90aa, 0x791508, 0x088683, 0xffdb38, 0xff3859, 0x7438ff, 0x38ff38, 0x38caff, 0xff38c4, 0x3883ff, 0xfffff3, 0x38f8ff, 0xff7a38, 0xdcff38, 0x3862ff, 0xb8b401]
		let curColor = 0
		
		let groupCalorie = ''
		let groupHeart = ''
		let groupDistance = ''
		let groupSteps = ''
		let groupStand = ''
		let groupBurn = ''
		let activity_cur1 = 0;
		let activity_cur2 = 0;
		let activity1_btn = ''
		let activity2_btn = ''

		let settingsScreen = ''
		let settings_btn
		let longPress_Timer = null;
		let longPressDelay = 850;
		let checkBT;
		let switch_checkBT;
		let switch_hourlyVibro;
		let switch_randomColor;
		
		let colorScreen = ''
		let colorR = 184
		let colorG = 180
		let colorB = 1
		let customColor = ''
		let customColorText = ''
		let customColor_bg = ''
		
		let halfsec_Timer = null;
		let dotsVisible = false;
		let animOn;
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		let everyHourVibro = false;
		let randomColor = true;
		let hourlyVibro_img;

		var curAODmode;
		let AODmodes = ["пустой", "часы", "часы и дата"];
		let AODmodeName;
		let dayNameText;
		let dateText;

		let delay_Timer = null;
		let clicks = 0;
		let clicksDelay = 370;

		function randomInt(min, max) {
		  let rand = min + Math.random() * (max + 1 - min);
		  return Math.floor(rand);
		}


		function fillColor() {
			bg_fill.setProperty(hmUI.prop.MORE, { 
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				color: bgColor[curColor] 
			});
		}

		function fillRandomColor(random = true) {		// случайный цвет или следующий из списка
			if(random) curColor = (curColor + randomInt(1, bgColor.length - 1)) % bgColor.length;
			else curColor = (curColor + 1) % bgColor.length;
			fillColor();				
		}


		function showAppScreen1(){
			vibro();
			hmApp.startApp({ url: 'activityAppScreen', native: true });
		}

		function showAppScreen2() {
			let url;
			vibro();

			switch(activity_cur2) {
			   case 1:
					url = 'PAI_app_Screen';
				break;
			   case 2:
					url = 'activityAppScreen';
				break;
			   default:
					url = 'heart_app_Screen';
				break;
			}
			
			hmApp.startApp({ url: url, native: true });
		}


//--------------------- контроль потери связи  ---------------------
		
		function checkConnection(check = true) {
			hmBle.removeListener;
			if (check){
				hmBle.addListener(function (status) {
					if(!status && checkBT) {
						hmUI.showToast({text: "Нет связи!!!"});
						vibro(9);
					}
				})			
			} 
		}

		function toggleСheckConnection() {
			checkBT = !checkBT;
			hmFS.SysProSetBool('nsw_checkBT', checkBT);
			vibro();		// вибрация при смене
			checkConnection(checkBT);
			switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png'); 
        }

//--------------------------------------------------------------- \\

//--------------------- мигание точек  --------------------- 
		function showDots() {
			dotsVisible = !dotsVisible;
			normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, dotsVisible);
		}


        function toggleDotsAnim() {		
			animOn = !animOn;
			setDotsAnim(animOn);
			hmFS.SysProSetBool('nsw_animOn', animOn);
			hmUI.showToast({text: "Анимация " + (animOn ? "включена" : "отключена")});
        }

        function setDotsAnim(on) {		

			if (on){
				if (halfsec_Timer == null) halfsec_Timer = timer.createTimer(1000 - curTime.utc % 1000, 500, showDots, {});
			} else {
				if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
				halfsec_Timer = null;
				normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			}
	
        }

//--------------------- мигание точек  --------------------- \\

//--------------------- вибрация каждый час  ---------------------
		function toggleEveryHourVibro() {
			everyHourVibro = !everyHourVibro;
			hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			vibro();		// вибрация при смене
			//hourlyVibro_img.setProperty(hmUI.prop.VISIBLE, everyHourVibro);
			switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 

        }

		function setEveryHourVibro() {
			curTime.addEventListener(curTime.event.MINUTEEND, function () {
					if (everyHourVibro && !(curTime.minute % 60)) vibro(27);
			});

        }

//--------------------------------------------------------------- \\

       function checkClicks() {		

			switch(clicks) {
			   case 2:
					showColorScreen();
				break;
			   default:
					fillRandomColor(false);
				break;
			}

			timer.stopTimer(delay_Timer);
			clicks = 0;
        }


        function getClick() {
			clicks++;
			if(delay_Timer) timer.stopTimer(delay_Timer);
			delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
			vibro();
        }



		function toggleRandomColor() {
			randomColor = !randomColor;
			hmFS.SysProSetBool('letc_randomColor', randomColor);
			vibro();		// вибрация при смене
			switch_randomColor.setProperty(hmUI.prop.SRC, randomColor ? 'slider_on.png' : 'slider_off.png'); 

        }



		function RGBtoHEX(r, g, b){
			return "0x" + r.toString(16).padStart(2, "0") + g.toString(16).padStart(2, "0") + b.toString(16).padStart(2, "0")
		}


        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

	// ---------------------------- загрузка настроек ----------------------------
		function loadSettings() {
			if (hmFS.SysProGetInt('letc_aod') === undefined) {
				curAODmode = 1;
				hmFS.SysProSetInt('letc_aod', curAODmode);
			} else {
				curAODmode = hmFS.SysProGetInt('letc_aod');
			}
			
			if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
				checkBT = false;
				hmFS.SysProSetBool('nsw_checkBT', checkBT);
			} else {
				checkBT = hmFS.SysProGetBool('nsw_checkBT');
			}
			
			if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
				everyHourVibro = false;
				hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			} else {
				everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
			}
			
			if (hmFS.SysProGetBool('nsw_animOn') === undefined) {
				animOn = true;
				hmFS.SysProSetBool('nsw_animOn', animOn);
			} else {
				animOn = hmFS.SysProGetBool('nsw_animOn');
			}
			
			if (hmFS.SysProGetBool('letc_randomColor') === undefined) {
				randomColor = true;
				hmFS.SysProSetBool('letc_randomColor', randomColor);
			} else {
				randomColor = hmFS.SysProGetBool('letc_randomColor');
			}
			
			if (hmFS.SysProGetChars('letc_customColor') === undefined) {
				colorR = 184;
				colorG = 108;
				colorB = 1;
				saveCustomColor();
			} else {
				let customColor_str = hmFS.SysProGetChars('letc_customColor');
				[colorR, colorG, colorB] = customColor_str.split(":").map((v) => parseInt(v));
				customColor = RGBtoHEX(colorR, colorG, colorB);
				if (bgColor[bgColor.length - 1] != customColor) bgColor[bgColor.length - 1] = customColor;
			}
			
		}

		function saveCustomColor() {
			hmFS.SysProSetChars('letc_customColor', `${colorR}:${colorG}:${colorB}`);
			customColor = RGBtoHEX(colorR, colorG, colorB);
			bgColor[bgColor.length - 1] = customColor;
		}

			
//------------------------ автозамена иконок погоды -----------------------------------

		let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]

		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			// время восхода
		let sunsetMins_def = 20 * 60;			// и заката по умолчанию

		let curMins = '';
		
		let isDayIcons = true;
		let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
		
		function autoToggleWeatherIcons() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
					}
					isDayIcons = true;
				}
			} else {
				if(isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
					}
					isDayIcons = false;
				}
			}
		}

//------------------------ автозамена иконок погоды ----------------------------------- \\

		function toggleActivity1() {							// переключаем видимость 1-й группы активностей по кругу

			let message = ["Шаги", "Расстояние", "Разминка"];
			activity_cur1 = (activity_cur1 + 1) % 3;
			vibro();
			groupSteps.setProperty(hmUI.prop.VISIBLE, activity_cur1 == 0);
			groupDistance.setProperty(hmUI.prop.VISIBLE, activity_cur1 == 1);
			groupStand.setProperty(hmUI.prop.VISIBLE, activity_cur1 == 2);
			hmUI.showToast({text: message[activity_cur1]});
        }

		function toggleActivity2() {							// переключаем видимость 2-й группы активностей по кругу

			let message = ["Пульс", "Калории", "Время жиросжигания"];
			activity_cur2 = (activity_cur2 + 1) % 3;
			vibro();
			groupHeart.setProperty(hmUI.prop.VISIBLE, activity_cur2 == 0);
			groupCalorie.setProperty(hmUI.prop.VISIBLE, activity_cur2 == 1);
			groupBurn.setProperty(hmUI.prop.VISIBLE, activity_cur2 == 2);
			hmUI.showToast({text: message[activity_cur2]});
        }

		function setActivitiesVisibility() {				// устанавливаем первоначальную видимость виджетов 
			groupDistance.setProperty(hmUI.prop.VISIBLE, false);
			groupStand.setProperty(hmUI.prop.VISIBLE, false);
			groupCalorie.setProperty(hmUI.prop.VISIBLE, false);
			groupBurn.setProperty(hmUI.prop.VISIBLE, false);
        }



// ---------------------------- экран настроек ----------------------------


		function toggleAODmode() {
			curAODmode = (curAODmode + 1) % AODmodes.length;
			hmFS.SysProSetInt('letc_aod', curAODmode);
			vibro();		// вибрация при смене
			AODmodeName.setProperty(hmUI.prop.TEXT, AODmodes[curAODmode]);
        }

	
		function createSettingsScreen() {

			settingsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
			settingsScreen.setProperty(hmUI.prop.VISIBLE, false);

            settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 480,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
			});
			
			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 82,
				w: 480,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКИ",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

            switch_checkBT = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 165,
              w: 62,
              h: 34,
              src: checkBT ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 155,
				y: 150,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация при потере связи",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 150,
              w: 371,
              h: 72,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleСheckConnection();
			});


            switch_hourlyVibro = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 235,
              w: 62,
              h: 34,
              src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 155,
				y: 220,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация в начале часа",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 220,
              w: 371,
              h: 72,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleEveryHourVibro();
			});

            switch_randomColor = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 305,
              w: 62,
              h: 34,
              src: randomColor ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 155,
				y: 290,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Менять цвет циферблата",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 290,
              w: 371,
              h: 72,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleRandomColor();
			});

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 72,
				y: 360,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Режим AOD",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			AODmodeName = settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 155,
				y: 407,
				w: 320,
				h: 64,
				text_size: 32,
				text: AODmodes[curAODmode],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});
			
			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 360,
              w: 350,
              h: 118,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleAODmode();
			});
			
		}

		function showSettingsScreen(value = true) {
			settingsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function openSettingsScreen() {
			if(longPress_Timer) timer.stopTimer(longPress_Timer);
			vibro();
			showSettingsScreen();
		}

// ---------------------------- экран настроек ---------------------------- \\


// ---------------------------- экран настройки цвета ----------------------------

		function setCustomColor() {
			
			customColor = RGBtoHEX(colorR, colorG, colorB);
			customColor_bg.setProperty(hmUI.prop.MORE, {
			  x: 60,
			  y: 70,
			  w: 360,
			  h: 350,
			  radius: 60,
			  color: customColor,
			});
			customColorText.setProperty(hmUI.prop.TEXT, `( ${colorR}, ${colorG}, ${colorB})`);
			
		}

	
		function createColorScreen() {

			colorScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
			colorScreen.setProperty(hmUI.prop.VISIBLE, false);

            colorScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			customColor_bg = colorScreen.createWidget(hmUI.widget.FILL_RECT, {
			  x: 60,
			  y: 70,
			  w: 360,
			  h: 350,
			  radius: 60,
			  color: RGBtoHEX(colorR, colorG, colorB),
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 480,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					hideColorScreen();
			});
			
			colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 83,
				w: 480,
				h: 64,
				text_size: 36,
				text: "СВОЙ ЦВЕТ",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});


			// R -10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 70,
			  y: 155,
			  text: '-10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorR = colorR - 10;
				if (colorR < 0) colorR = 256 + colorR;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// R -
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 142,
			  y: 155,
			  text: '-',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorR--;
				if (colorR < 0) colorR = 256 + colorR;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 234,
				y: 155,
				w: 320,
				h: 64,
				text_size: 32,
				text: "R",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			// R +
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 276,
			  y: 155,
			  text: '+',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorR++;
				if (colorR > 255) colorR =  colorR - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// R +10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 348,
			  y: 155,
			  text: '+10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorR = colorR + 10;
				if (colorR > 255) colorR =  colorR - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// G -10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 70,
			  y: 225,
			  text: '-10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorG = colorG - 10;
				if (colorG < 0) colorG = 256 + colorG;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// G -
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 142,
			  y: 225,
			  text: '-',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorG--;
				if (colorG < 0) colorG = 256 + colorG;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 234,
				y: 225,
				w: 320,
				h: 64,
				text_size: 32,
				text: "G",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			// G +
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 276,
			  y: 225,
			  text: '+',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorG++;
				if (colorG > 255) colorG =  colorG - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// G +10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 348,
			  y: 225,
			  text: '+10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorG = colorG + 10;
				if (colorG > 255) colorG =  colorG - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// B -10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 70,
			  y: 295,
			  text: '-10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorB = colorB - 10;
				if (colorB < 0) colorB = 256 + colorB;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// B -
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 142,
			  y: 295,
			  text: '-',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorB--;
				if (colorB < 0) colorB = 256 + colorB;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 234,
				y: 295,
				w: 320,
				h: 64,
				text_size: 32,
				text: "B",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			// B +
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 276,
			  y: 295,
			  text: '+',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorB++;
				if (colorB > 255) colorB = colorB - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// B +10
			colorScreen.createWidget(hmUI.widget.BUTTON, {
			  x: 348,
			  y: 295,
			  text: '+10',
			  text_size: 32,
			  w: 62,
			  h: 62,
			  normal_color: 0x999999,
			  press_color: 0xCCCCCC,
			  click_func: () => {
				colorB = colorB + 10;
				if (colorB > 255) colorB = colorB - 256;
				setCustomColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			colorScreen.createWidget(hmUI.widget.FILL_RECT, {
			  x: 101,
			  y: 380,
			  w: 268,
			  h: 55,
			  radius: 20,
			  color: 0x999999,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			customColorText = colorScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 375,
				w: 480,
				h: 64,
				text_size: 34,
				text: `( ${colorR}, ${colorG}, ${colorB})`,
				color: '0xFFFFFFCC',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});
			
		}

		function showColorScreen() {
			colorScreen.setProperty(hmUI.prop.VISIBLE, true);
		}

		function hideColorScreen() {
			vibro();
			colorScreen.setProperty(hmUI.prop.VISIBLE, false);
			curColor = bgColor.length - 1;
			bgColor[curColor] = customColor;
			saveCustomColor();
			fillColor();
		}


// ---------------------------- экран настройки цвета ---------------------------- \\


		function getCurrentDate() {
			return curTime.day.toString().padStart(2, "0") + "." + curTime.month.toString().padStart(2, "0") + "." + curTime.year.toString();
        }

		function getCurrentDayName() {
			let day_names = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];
			return  day_names[curTime.week - 1];
        }

// ---------------------------- AOD ----------------------------

		function makeAOD() {
			
			let mode = hmFS.SysProGetInt('letc_aod');
			idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 0,
			  y: 0,
			  w: 480,
			  h: 480,
			  color: '0xFF000000',
			  show_level: hmUI.show_level.ONLY_AOD,
			});

			if (mode){			// часы

				idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 68,
				  hour_startY: 190,
				  hour_array: ["dig0.png","dig1.png","dig2.png","dig3.png","dig4.png","dig5.png","dig6.png","dig7.png","dig8.png","dig9.png"],
				  hour_zero: 1,
				  hour_space: 8,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 269,
				  minute_startY: 190,
				  minute_array: ["dig0.png","dig1.png","dig2.png","dig3.png","dig4.png","dig5.png","dig6.png","dig7.png","dig8.png","dig9.png"],
				  minute_zero: 1,
				  minute_space: 8,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});

				normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 234,
				  y: 205,
				  src: 'dots.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				setDotsAnim(animOn);
			}
			
			
			if (mode > 1){			// часы + дата 

				dateText = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 0,
					y: 105,
					w: 480,
					h: 40,
					text_size: 36,
					color: '0xFFFFFFF3',
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text: getCurrentDate(),
				});
				
				dayNameText = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 0,
					y: 52,
					w: 480,
					h: 50,
					text_size: 36,
					color: '0xFFFFFFF3',
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text: getCurrentDayName(),
				});

			}
		
			//маска затемнения для AOD
			hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  w: 480,
			  h: 480,
			  src: 'bg_fill_50.png',
			  show_level: hmUI.show_level.ONLY_AOD,
			});		
		
			if (mode){			
				idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 230,
				  y: 383,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});
			}
		
		
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					stopVibro();
				}),
				pause_call: (function () {
					stopVibro();
				}),
			});	
			
			checkConnection(hmFS.SysProGetBool('nsw_checkBT'));
			setEveryHourVibro();
		}

// ---------------------------- AOD --------------------------- \\



        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
				bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 0,
				  w: 480,
				  h: 480,
				  color: bgColor[curColor],
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
					
				normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  w: 480,
				  h: 480,
				  src: 'bg.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 31,
				  y: 226,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 423,
				  y: 165,
				  src: 'ico_settings.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 247,
				  y: 405,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  unit_sc: 's_deg.png',
				  unit_tc: 's_deg.png',
				  unit_en: 's_deg.png',
				  negative_image: 's_minus.png',
				  invalid_image: 's_minus.png',
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				autoToggleWeatherIcons();
				normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
				  x: 175,
				  y: 386,
				  image_array: weather_icons,
				  image_length: 29,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
				  x: 177,
				  y: 128,
				  week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
				  week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
				  week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
				  month_startX: 175,
				  month_startY: 93,
				  month_sc_array: ["month01.png","month02.png","month03.png","month04.png","month05.png","month06.png","month07.png","month08.png","month09.png","month10.png","month11.png","month12.png"],
				  month_tc_array: ["month01.png","month02.png","month03.png","month04.png","month05.png","month06.png","month07.png","month08.png","month09.png","month10.png","month11.png","month12.png"],
				  month_en_array: ["month01.png","month02.png","month03.png","month04.png","month05.png","month06.png","month07.png","month08.png","month09.png","month10.png","month11.png","month12.png"],
				  month_is_character: true ,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
				  day_startX: 79,
				  day_startY: 92,
				  day_sc_array: ["m_dig0.png","m_dig1.png","m_dig2.png","m_dig3.png","m_dig4.png","m_dig5.png","m_dig6.png","m_dig7.png","m_dig8.png","m_dig9.png"],
				  day_tc_array: ["m_dig0.png","m_dig1.png","m_dig2.png","m_dig3.png","m_dig4.png","m_dig5.png","m_dig6.png","m_dig7.png","m_dig8.png","m_dig9.png"],
				  day_en_array: ["m_dig0.png","m_dig1.png","m_dig2.png","m_dig3.png","m_dig4.png","m_dig5.png","m_dig6.png","m_dig7.png","m_dig8.png","m_dig9.png"],
				  day_zero: 1,
				  day_space: 0,
				  day_align: hmUI.align.RIGHT,
				  day_is_character: false,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 210,
				  y: 36,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 3,
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.BATTERY,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupHeart = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 294,
				  y: 319,
				  w: 160,
				  h: 50,
				});

				groupHeart.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_pulse.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rate_text_text_img = groupHeart.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 47,
				  y: 10,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.HEART,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupCalorie = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 294,
				  y: 319,
				  w: 160,
				  h: 50,
				});

				groupCalorie.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_kcal.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calorie_current_text_img = groupCalorie.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 47,
				  y: 10,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.CAL,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupBurn = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 294,
				  y: 319,
				  w: 160,
				  h: 50,
				});
					
				groupBurn.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_burn.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
					
				normal_fat_burning_current_text_img = groupBurn.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 47,
				  y: 10,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.FAT_BURNING,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupSteps = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 78,
				  y: 311,
				  w: 160,
				  h: 60,
				});

				groupSteps.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_steps.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img = groupSteps.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 56,
				  y: 18,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.STEP,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupDistance = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 78,
				  y: 311,
				  w: 160,
				  h: 60,
				});

				groupDistance.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_dist.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_text_text_img = groupDistance.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 56,
				  y: 18,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  unit_sc: 'km.png',
				  unit_tc: 'km.png',
				  unit_en: 'km.png',
				  dot_image: 's_dot.png',
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.DISTANCE,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				groupStand = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 78,
				  y: 311,
				  w: 160,
				  h: 60,
				});

				groupStand.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'ico_stand.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stand_current_text_img = groupStand.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 56,
				  y: 18,
				  font_array: ["s_dig0.png","s_dig1.png","s_dig2.png","s_dig3.png","s_dig4.png","s_dig5.png","s_dig6.png","s_dig7.png","s_dig8.png","s_dig9.png"],
				  padding: false,
				  h_space: 2,
				  align_h: hmUI.align.LEFT,
				  type: hmUI.data_type.STAND,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				setActivitiesVisibility();

				normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 68,
				  hour_startY: 190,
				  hour_array: ["dig0.png","dig1.png","dig2.png","dig3.png","dig4.png","dig5.png","dig6.png","dig7.png","dig8.png","dig9.png"],
				  hour_zero: 1,
				  hour_space: 8,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 269,
				  minute_startY: 190,
				  minute_array: ["dig0.png","dig1.png","dig2.png","dig3.png","dig4.png","dig5.png","dig6.png","dig7.png","dig8.png","dig9.png"],
				  minute_zero: 1,
				  minute_space: 8,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 234,
				  y: 205,
				  src: 'dots.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				// смена цвета
				hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 0,
				  y: 0,
				  text: '',
				  w: 480,
				  h: 480,
				  normal_src: 'blank.png',
				  press_src: 'blank.png',
				  click_func: () => {
					fillRandomColor(false);
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
				  x: 277,
				  y: 190,
				  w: 129,
				  h: 101,
				  src: 'blank.png',
				  type: hmUI.data_type.COUNT_DOWN,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
				  x: 178,
				  y: 388,
				  w: 135,
				  h: 81,
				  src: 'blank.png',
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				//кнопка переключения 1-группы активностей и запуска активности по длинному тапу
				activity1_btn = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 71,
				  y: 309,
				  w: 155,
				  h: 62,
				  src: 'blank.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				activity1_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, showAppScreen1, {});

				});
				activity1_btn.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					toggleActivity1();
				});
				
				//кнопка переключения 2-группы активностей и запуска активности по длинному тапу
				activity2_btn = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 288,
				  y: 309,
				  w: 134,
				  h: 62,
				  src: 'blank.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				activity2_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, showAppScreen2, {});

				});
				activity2_btn.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					toggleActivity2();
				});
	
				// календарь
				hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 77,
				  y: 91,
				  text: '',
				  w: 319,
				  h: 67,
				  normal_src: 'blank.png',
				  press_src: 'blank.png',
				  click_func: () => {
					hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				//кнопка включеня/отключения анимации мигания точек
				hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 212,
				  y: 190,
				  text: '',
				  w: 58,
				  h: 101,
				  normal_src: 'blank.png',
				  press_src: 'blank.png',
				  click_func: () => {
					toggleDotsAnim();
				  },
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});

				// вызов экрана настроек по долгому тапу 
				settings_btn = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 415,
				  y: 148,
				  w: 58,
				  h: 57,
				  src: 'blank.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				settings_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, openSettingsScreen, {});
				});
				settings_btn.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					getClick();
				});

				// вызов экрана мировое время
				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 72,
				  y: 190,
				  w: 129,
				  h: 101,
				  src: 'blank.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				}).addEventListener(hmUI.event.CLICK_UP, function () {
					hmApp.startApp({ url: 'WorldClockScreen', native: true });
				});				

				createSettingsScreen();
				createColorScreen();
			
				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: (function () {
					if (randomColor) fillRandomColor();
					autoToggleWeatherIcons();
					setDotsAnim(animOn);
					stopVibro();
					checkConnection(checkBT);
					setEveryHourVibro();
				  }),
				  pause_call: (function () {
					stopVibro();
				  }),
				});
			

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
				loadSettings();
            },
            build() {
                n.log("index page.js on ready invoke")

				if (hmSetting.getScreenType() == hmSetting.screen_type.AOD){
					makeAOD();
				} else {
					this.init_view();
				}
			},
            onDestroy() {
                n.log("index page.js on destroy invoke")
				if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
				if(delay_Timer) timer.stopTimer(delay_Timer);
				vibrate && vibrate.stop();
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
